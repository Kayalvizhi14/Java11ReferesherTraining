package com.functionalprogramming;

import java.util.Arrays;
import java.util.List;

public class StreamApiExample {

	public static void main(String[] args) {

		List<String> l = Arrays.asList("Furniture", "clothing", "Food");

		long cargolist = l.stream().filter(e -> e.startsWith("c")).count();

		System.out.println(cargolist);
	}
}
