/*package com.hlag.logisticsystem.dto;

import java.util.List;
import java.util.Scanner;

public class CargoManager {

	private List<CargoItem> cargoItem;

	public CargoManager(List<CargoItem> cargoItem) {
		this.cargoItem = cargoItem;
	}

	public List<CargoItem> getCargoItem() {
		return cargoItem;
	}

	public void setCargoItem(List<CargoItem> cargoItem) {
		this.cargoItem = cargoItem;
	}

	public void addCargoItem(CargoItem item) {
		cargoItem.add(item);
		System.out.println("Cargo item added successfully.");
	}

	public void displayCargoItems() {
		if (cargoItem.isEmpty()) {
			System.out.println("No cargo items to display.");
		} else {
			System.out.println("Cargo Items:");
			for (int i = 0; i < cargoItem.size(); i++) {
				System.out.println((i + 1) + ". " + cargoItem.get(i));
			}
		}
	}

	public void removeCargoItem(int index) {
		if (index >= 0 && index < cargoItem.size()) {
			cargoItem.remove(index);
			System.out.println("Cargo item removed successfully.");
		} else {
			System.out.println("Invalid index. No item removed.");
		}
	}

	public static void main(String[] args) {
		CargoManager manager = new CargoManager(null);
		Scanner scanner = new Scanner(System.in);

		while (true) {

			System.out.println("1. Add Cargo Item");
			System.out.println("2. Remove Cargo Item");
			System.out.println("3. Display All Cargo Items");
			System.out.println("4. Exit");
			System.out.print("Choose an option: ");

			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
				case 1:
					System.out.print("Enter weight (kg): ");
					double weight = scanner.nextDouble();
					scanner.nextLine();

					System.out.print("Enter dimensions (LxWxH): ");
					String dimensions = scanner.nextLine();

					System.out.print("Enter type (e.g., fragile, standard): ");
					String type = scanner.nextLine();

					CargoItem newItem = new CargoItem(weight, dimensions, type);
					manager.addCargoItem(newItem);
					break;

				case 2:
					System.out.print("Enter the index of the item to remove: ");
					int index = scanner.nextInt() - 1;
					manager.removeCargoItem(index);
					break;

				case 3:
					manager.displayCargoItems();
					break;

				case 4:
					System.out.println("Exiting...");
					scanner.close();
					return;

				default:
					System.out.println("Invalid option. Try again.");
			}
		}
	}
}
*/