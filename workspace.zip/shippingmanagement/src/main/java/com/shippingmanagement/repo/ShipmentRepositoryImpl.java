package com.shippingmanagement.repo;

import java.util.Optional;

import com.shippingmanagement.entity.Shipment;
import com.shippingmanagement.entity.User;

public class ShipmentRepositoryImpl implements ShipmentRepository {

	@Override
	public Shipment add(Shipment shipment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Shipment> getUserById(String id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Shipment update(String id, User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub

	}

}
