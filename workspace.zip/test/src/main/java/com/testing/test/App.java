package com.testing.test;

import java.util.Optional;

import com.hlag.testing.test.entity.User;
import com.testing.test.Exception.InvalidNameException;
import com.testing.test.service.UserService;
import com.testing.test.service.UserServiceImpl;

public class App {

	private String ADD;

	public static void main(String[] args) {

		UserService userService = UserServiceImpl.getInstance();

		User user = null;

		String operationString = "ADD"; // This can be changed to "GET_BY_ID", "UPDATE", etc.
		performOperation(operationString, userService);
	}

	private static void performOperation(String operationString, UserService userService) {
		// Directly use the operationString in the switch statement
		switch (operationString) {
			case "ADD":
				try {
					User newUser = new User("kayal", "1234567890", "ex@gmail.com", "kayal@12");
					User addedUser = userService.addUser(newUser);
					if (addedUser != null) {
						System.out.println("User added successfully: " + addedUser);
					}
				} catch (InvalidNameException e) {
					System.out.println("Failed to add user: " + e.getMessage());
				}
				break;

			case "GET_BY_ID":
				String userId = "<insert-valid-UUID-here>";
				Optional<User> userOpt = userService.getUserById(userId);
				if (userOpt.isPresent()) {
					System.out.println("User found: " + userOpt.get());
				} else {
					System.out.println("User not found.");
				}
				break;

			case "UPDATE":
				userId = "<insert-valid-UUID-here>";
				Optional<User> userToUpdateOpt = userService.getUserById(userId);
				if (userToUpdateOpt.isPresent()) {
					User userToUpdate = userToUpdateOpt.get();
					/*			userToUpdate.setName("Kayal Updated");
								userToUpdate.setEmail("updated@example.com");*/
					// userService.UpdateUser(userId, )
					System.out.println("User updated successfully: " + userToUpdate);
				} else {
					System.out.println("User not found.");
				}
				break;

			case "DELETE":
				userId = "<insert-valid-UUID-here>";
				userService.deleteUser(userId);
				System.out.println("User deleted successfully, if found.");
				break;

			case "DISPLAY_ALL":
				Optional<java.util.List<User>> users = userService.getUsers();
				if (users.isPresent() && !users.get().isEmpty()) {
					users.get().forEach(System.out::println);
				} else {
					System.out.println("No users found.");
				}
				break;

			default:
				System.out.println("Invalid operation.");
				break;
		}

		/*try {
			User user = new User("jk", operationString, operationString, operationString)
			user = new User("kayal", "1234567890", "ex@gmail.com", "kayal@12");
		
			User user2 = userService.addUser(user);
			if (user2 != null) {
				System.out.println("User added succesfully");
			}
		
			Optional<User> optional = userService.getUserById(user2.getUserId().toString());
			if (optional.isPresent()) {
				System.out.println(optional.get());
			} else {
				System.out.println("No record");
			}
		} catch (InvalidNameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}
}
