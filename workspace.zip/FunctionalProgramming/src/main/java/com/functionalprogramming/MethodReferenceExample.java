package com.functionalprogramming;

import java.util.Arrays;
import java.util.List;

public class MethodReferenceExample {

	public static void main(String[] args) {

		List<String> list = Arrays.asList("Furniture" + "Clothing" + "Food");

		list.forEach(System.out::println);
	}
}
