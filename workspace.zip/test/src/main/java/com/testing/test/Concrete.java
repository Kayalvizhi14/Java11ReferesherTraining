package com.testing.test;

public class Concrete extends AbstractTest {

	@Override
	public void method1() {
		System.out.println("method 1 generated");

	}

	@Override
	public void main8() {
		System.out.println("method 8 generated");

	}

	@Override
	public void main9() {
		System.out.println("method 9 generated");

	}

	public static void main(String[] args) {
		
		I2 i1=new Concrete();
		// i1.
	}

}
