package com.productmanagement.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.productmanagement.Product;

public class ProductRepoImpl implements ProductRepo {

	List<Product> products = new ArrayList<>();

	@Override
	public Product add(Product product) {

		for (Product p : products) {
			if (p.getProductId().equals(product.getProductId())) {
				products.add(product);
			}
		}
		return product;
	}

	@Override
	public Optional<Product> getProductById(String id) {

		UUID uuid = UUID.fromString(id);
		for (Product p : products) {
			if (p.getProductId().equals(uuid)) {
				return Optional.of(p);
			}
		}
		return Optional.empty();
	}

	@Override
	public Optional<List<Product>> getAllProducts() {
		if (products.isEmpty()) {
			return Optional.empty();
		}
		return Optional.of(products);
	}

	@Override
	public Product update(String id, Product product) {
		for (int i = 0; i < products.size(); i++) {
			Product p = getProductById(id).get();
			if (p.getProductId().equals(product)) {
				products.set(i, product);
			}
		}
		return null;
	}

	@Override
	public void delete(String id) {
		products.removeIf(e -> products.get(0).getProductId().equals(id));

	}

	private static ProductRepoImpl impl;

	public static ProductRepoImpl getInstance() {
		if (impl == null) {
			impl = new ProductRepoImpl();
		}
		return impl;
	}
}
