package com.testing.test;


public abstract class test implements I1, I2, I3 {

	@Override
	public void main8() {
		// TODO Auto-generated method stub

	}

	@Override
	public void main9() {
		// TODO Auto-generated method stub

	}

	@Override
	public void main5() {
		// TODO Auto-generated method stub

	}

	@Override
	public void main6() {
		// TODO Auto-generated method stub

	}

	@Override
	public void main7() {
		// TODO Auto-generated method stub

	}

	@Override
	public void method1() {
		// TODO Auto-generated method stub

	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub

	}

	@Override
	public void method3() {
		// TODO Auto-generated method stub

	}

	@Override
	public void method4() {
		// TODO Auto-generated method stub

	}

}
