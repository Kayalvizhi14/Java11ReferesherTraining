package com.productmanagement.service;

import java.util.List;
import java.util.Optional;

import com.productmanagement.Product;
import com.productmanagement.repo.ProductRepo;
import com.productmanagement.repo.ProductRepoImpl;

public class ProductServiceImpl implements ProductService {

	ProductRepo productRepo = ProductRepoImpl.getInstance();
	@Override
	public Product add(Product product) {
		return productRepo.add(product);
	}

	@Override
	public Optional<Product> getProductById(String id) {
		return productRepo.getProductById(id);
	}

	@Override
	public Optional<List<Product>> getAllProducts() {
		return productRepo.getAllProducts();
	}

	@Override
	public Product update(String id, Product product) {
		return productRepo.update(id, product);
	}

	@Override
	public void delete(String id) {
		productRepo.delete(id);

	}

	private ProductServiceImpl() {
	}

	private static ProductServiceImpl impl;

	public static ProductServiceImpl getInstance() {
		if (impl == null) {
			impl = new ProductServiceImpl();
		}
		return impl;
	}

}
