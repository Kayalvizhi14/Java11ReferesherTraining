package com.hlag.logisticsystem;

public class Derived extends Base {

	public Derived(int value, int value2) {
		super(value, value2);
	}

	@Override
	public void test() {
		System.out.println("");
	}

	

}
