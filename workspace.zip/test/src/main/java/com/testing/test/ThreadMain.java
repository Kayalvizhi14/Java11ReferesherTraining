package com.testing.test;

import com.testing.test.repo.UserRepository;
import com.testing.test.repo.UserRepositoryImpl;

public class ThreadMain {

	public static void main(String[] args) {


		Runnable runnable = () -> {
			UserRepository userRepository = UserRepositoryImpl.getInstance();
			System.out.println(userRepository.getClass().hashCode());
			// IntStream.range(1, 10).forEach((e) -> Thread.currentThread().getName());

			try {
				Thread.sleep(1000);
				System.out.println(Thread.currentThread().getName());
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		};

		Thread thread = new Thread(runnable);

		try {
			thread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		thread.start();

		Thread thread2 = new Thread(runnable);
		try {
			thread2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		thread2.start();

		Thread thread3 = new Thread(runnable);
		try {
			thread3.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		thread3.start();
	}
}
