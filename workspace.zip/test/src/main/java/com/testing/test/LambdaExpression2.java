package com.testing.test;

import java.util.HashMap;
import java.util.Map;

public class LambdaExpression2 {

	public static void main(String[] args) {

		Map<String, Integer> map = new HashMap<>();
		map.put("A", 10);
		map.put("B", 20);
		map.put("C", 30);
		map.put("D", 40);
		map.put("E", 50);
		map.put("F", 60);

		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			System.out.println("Key :" + entry.getKey() + "Value :" + entry.getValue());
		}

		map.forEach((k, v) -> {
			System.out.println(k + " " + v);
		});

		IOps iops = (int a, int b) -> a + b;
		int res = iops.add(20, 40);
		System.out.println(res);

		demo((a, b) -> a + b + 10);
	}

	public static void demo(IOps iops) {
		System.out.println(iops.add(10, 20));
	}

	@FunctionalInterface
	interface IOps {

		public int add(int a, int b);
	}
}
