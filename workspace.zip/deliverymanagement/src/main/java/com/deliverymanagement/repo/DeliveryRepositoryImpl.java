package com.deliverymanagement.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.deliverymanagement.delivery.Delivery;
import com.deliverymanagement.exception.DataNotFoundException;

public class DeliveryRepositoryImpl implements DeliveryRepository {

	private List<Delivery> deliveries = new ArrayList<>();

	// Save a new delivery
	@Override
	public void save(Delivery delivery) {
		deliveries.add(delivery);
	}

	// Find a delivery by its ID
	@Override
	public Optional<Delivery> findById(String deliveryId) {
		// return deliveries.stream().filter(delivery -> delivery.getDeliveryId().equals(deliveryId)).findFirst();
		return deliveries.stream().filter(e -> e.getDeliveryId().equals(deliveryId)).findFirst();
	}

	// Get all deliveries
	@Override
	public List<Delivery> findAll() {
		// return new ArrayList<>(deliveries);
		return new ArrayList<>(deliveries);
	}

	// Update an existing delivery
	@Override
	/*	public void update(Delivery delivery) {
			Optional<Delivery> existingDelivery = findById(delivery.getDeliveryId());
			if (existingDelivery.isPresent()) {
				deliveries.remove(existingDelivery.get());
				deliveries.add(delivery);
			}
		}*/

	public void update(Delivery delivery) {
		Optional<Delivery> d = findById(delivery.getDeliveryId());
		if (d.isPresent()) {
			deliveries.remove(d.get());
			deliveries.add(delivery);
		}
	}

	// Delete a delivery by its ID
	@Override
	public void deleteById(String deliveryId) {
		// deliveries.removeIf(delivery -> delivery.getDeliveryId().equals(deliveryId));
		deliveries.removeIf(e -> e.getDeliveryId().equals(deliveryId));
	}

	// Get deliveries that are completed
	@Override
	public List<Delivery> findCompletedDeliveries() {
		List<Delivery> completedDeliveries = new ArrayList<>();

		return completedDeliveries.stream().filter(e -> e.isCompleted()).collect(Collectors.toList());

		/*for (Delivery delivery : deliveries) {
			if (delivery.isCompleted()) {
				completedDeliveries.add(delivery);
			}
		}
		return completedDeliveries;*/
	}

	// Retrive deliveries where revenue exceeds a specific threshold(50)

	@Override
	public List<Delivery> getRevenue(String revenue) {
		int threshold = 50;
		return deliveries.stream().filter(delivery -> delivery.getRevenue() > threshold).collect(Collectors.toList());

	}

	// Update : Modify delivery details mark a delivery completed

	@Override
	public List<Delivery> updateModifier(String id) {
		// list.stream()
		// . filter()

		return deliveries.stream().map(delivery -> {
			if (delivery.getDeliveryId().equals(id)) {
				delivery.setCompleted(true);
			}
			return delivery;
		}).collect(Collectors.toList());

		/*	List<Delivery> delivery = new ArrayList<>();
			return delivery.stream()
					.filter(e -> e.getDeliveryId().equals(id) )
					.collect(Collectors.toList());*/

	}

	@Override
	public void deleteCompleted(String id) {
		List<Delivery> completedDeliveries = new ArrayList<>();
		completedDeliveries.removeIf(e -> !e.isCompleted());
	}

	@Override
	public double calculateTotalRevenue() {
		return deliveries.stream().mapToDouble(e -> e.getRevenue()).sum();
	}

	@Override
	public double averageDeliveryTime() throws DataNotFoundException {
		return deliveries.stream()
				.mapToDouble(e -> e.getDeliveryTimeInHours())
				.average()
				.orElseThrow(() -> new DataNotFoundException("Data not found"));
	}

	/*public List<Delivery> findTopPerformingDeliveries(int k) {
		return deliveries.stream()
				.filter(e -> e.isCompleted())
				.sorted((a, b) -> Double.compare(a.getDeliveryTimeInHours(), b.getDeliveryTimeInHours()))
				.limit(k)
				.collect(Collectors.toList());
	
	}*/

	public List<Delivery> topPerformingDeliveries(int k) {
		return deliveries.stream()
				.filter(e -> e.isCompleted())
				.sorted((a, b) -> Double.compare(a.getDeliveryTimeInHours(), b.getDeliveryTimeInHours()))
				.limit(k)
				.collect(Collectors.toList());

	}

}
