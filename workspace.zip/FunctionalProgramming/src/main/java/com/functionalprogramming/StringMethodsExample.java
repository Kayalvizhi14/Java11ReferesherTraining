package com.functionalprogramming;

public class StringMethodsExample {

	public static void main(String[] args) {

		String str = "  Hello, World!  ";

		// isBlank()
		System.out.println("Is string blank? " + str.isBlank());

		// lines()
		str.lines().forEach(System.out::println);

		// strip()
		System.out.println("Stripped string: '" + str.strip() + "'");

	}
}
