package com.hlag.inventorymanagementsystem.entity.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.exception.InvalidNameException;

public class ProductRepositoryImpl implements ProductRepository {

	List<Product> products = new ArrayList<>();

	@Override
	public Optional<Product> addProduct(String id) throws InvalidNameException {
		for (Product p : products) {
			if (p.getProductId().equals(id)) {
				throw new InvalidNameException("Book already exists: ");
			}
			products.add(p);
		}
		return Optional.empty();

	}

	@Override
	public Optional<List<Product>> getProduct(String id) {
		for (Product product : products) {
			if (product.getProductId().equals(id)) {
				Optional.of(product);
			}
		}
		return Optional.empty();
	}

	@Override
	public Optional<Product> getById(String id) {
		UUID uuid = UUID.fromString(id);
		return products.stream().filter(e -> e.getProductId().toString().equals(id)).findFirst();

	}

	@Override
	public Product updateUser(String id, Product product) {
		for (int i = 0; i < products.size(); i++) {
			Optional<Product> result = getById(id);
			if (result.isPresent()) {
				products.set(i, product);
			}
		}
		return null;
	}

	@Override
	public void delete(String id) {
		for (Product product : products) {
			if (product.getProductId().equals(id)) {
				products.remove(0);

			}
		}
	}

	private ProductRepositoryImpl() {
	}

	private static ProductRepositoryImpl productRepositoryImpl;

	public static ProductRepositoryImpl getInstance() {
		if (productRepositoryImpl == null) {
			productRepositoryImpl = new ProductRepositoryImpl();
		}
		return productRepositoryImpl;
	}
}
