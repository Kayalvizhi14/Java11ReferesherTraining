package com.shippingmanagement.repo;

import java.util.Optional;

import com.shippingmanagement.entity.Shipment;
import com.shippingmanagement.entity.User;

public interface ShipmentRepository {

	public Shipment add(Shipment shipment);

	public Optional<Shipment> getUserById(String id);

	public Shipment update(String id, User user);

	public void delete(String id);
}
