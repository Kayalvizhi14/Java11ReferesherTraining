package com.testing.test.repo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.hlag.testing.test.entity.User;

public class UserRepositoryImpl implements UserRepository {

	// List<User> userList = new ArrayList<>();
	// List<User> userList = new LinkedList<>();
	Set<User> userList = new HashSet();

	@Override
	public User addUser(User user) {
		boolean result = userList.add(user);
		if (result) {
			return user;
		}
		return null;
	}

	@Override
	public Optional<User> getUserById(String id) {
		UUID uuid = UUID.fromString(id);
		return userList.stream().filter(e -> e.getUserId().toString().equals(id)).findFirst();
		/*AtomicReference<User> atomicReference = new AtomicReference<>();
		Consumer<User> consumer = e -> {
			if (e.getUserId().toString().equals(id)) {
				atomicReference.set(e);
			}
		};
		
		userList.forEach(consumer);
		User user3 = atomicReference.get();
		return Optional.ofNullable(user3);*/
	}

	@Override
	public Optional<List<User>> getUsers() {

		if (userList.isEmpty()) {
			return Optional.empty();
		} else {
			// return Optional.of(userList);
			return Optional.of(new ArrayList<>(userList));
		}
	}

	@Override
	public void deleteUser(String id) {
		UUID uuid = UUID.fromString(id);
		userList.removeIf(user -> user.getUserId().equals(uuid));

	}

	@Override
	public User UpdateUser(String id, String user) {

		for (int i = 0; i < userList.size(); i++) {
			User users = getUserById(id).get();
			if (users.getUserId().equals(id)) {
				userList.remove(i);
				userList.add(users);
				return UpdateUser(id, user);
			}
		}
		return null;
	}

	private UserRepositoryImpl() {
	}

	private static UserRepositoryImpl impl;

	public static UserRepositoryImpl getInstance() {
		if (impl == null) {
			impl = new UserRepositoryImpl();
		}
		return impl;
	}
}
