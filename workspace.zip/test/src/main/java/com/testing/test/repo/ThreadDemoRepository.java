package com.testing.test.repo;

import java.util.stream.IntStream;

public class ThreadDemoRepository {

	public static void main(String[] args) {

		Runnable runnable = () -> {

			IntStream.range(1, 10).forEach((e) -> Thread.currentThread().getName());

			try {
				Thread.sleep(1000);
				System.out.println(Thread.currentThread().getName());
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		};
	}
}
