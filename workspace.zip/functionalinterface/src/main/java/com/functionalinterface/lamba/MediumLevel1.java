package com.functionalinterface.lamba;

public class MediumLevel1 {

	public static void main(String[] args) {

		Comparator<String> i = (o1, o2) -> Integer.compare(o1.length(), o2.length());
		System.out.println(i.compare("kayal", "paul"));
	}
}

interface Comparator<T> {

	int compare(T o1, T o2);
}