package com.testing.test;

public class AddOrEvenLambda {

	public static void main(String[] args) {

		Add add = number -> number % 2 == 0;

		if (add.check(10)) {
			System.out.println("Even");
		} else {
			System.out.println("Odd");
		}
	}
}

@FunctionalInterface
interface Add {
	boolean check(int number);
}