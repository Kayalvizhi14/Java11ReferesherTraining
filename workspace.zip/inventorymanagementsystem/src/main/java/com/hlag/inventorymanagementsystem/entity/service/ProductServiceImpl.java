package com.hlag.inventorymanagementsystem.entity.service;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.entity.repo.ProductRepository;
import com.hlag.inventorymanagementsystem.entity.repo.ProductRepositoryImpl;

public class ProductServiceImpl implements ProductService {

	ProductRepository productRepository = ProductRepositoryImpl.getInstance();
	ProductService productService = null;
	@Override
	public Optional<Product> getById(String id) {
		return productRepository.getById(id);
	}

	@Override
	public Optional<List<Product>> getProduct(String id) {
		return getProduct(id);
	}

	@Override
	public void delete(String id) {
		delete(id);
	}

	@Override
	public Product updateUser(String id, Product product) {
		return productRepository.updateUser(id, product);
	}

	@Override
	public Optional<Product> addProduct(Product product) {
		return Optional.of(product);
	}

	private ProductServiceImpl() {
	}

	private static ProductServiceImpl productServiceImpl;

	public static ProductServiceImpl getInstance() {
		if (productServiceImpl == null) {
			productServiceImpl = new ProductServiceImpl();
		}
		return productServiceImpl;
	}

}
