package com.hlag.usermanagement.entity;

import java.util.UUID;
import java.util.regex.Pattern;

import com.hlag.usermanagement.Exception.InvalidNameException;

public class User {

	private Pattern MOBILE_NUMBER_PATTERN = Pattern.compile("^\\d{10}$");
	private UUID id;
	private String name;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	private String contactNumber;

	public User(
			UUID id,
			String name,
			String password,
			String firstName,
			String lastName,
			String email,
			String contactNumber) {

		id = UUID.randomUUID();
		this.name = name;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNumber = contactNumber;
	}

	public UUID getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) throws InvalidNameException {
		if (name.length() > 15 && name == null) {
			throw new InvalidNameException("Name shoulldn't be Null");
		}
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) throws InvalidNameException {
		if (password.length() > 8 && password == null) {
			throw new InvalidNameException("Password should atleast be 8 characters");
		}
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

}
