package com.hlag.inventorymanagementsystem.app;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.entity.service.ProductService;
import com.hlag.inventorymanagementsystem.entity.service.ProductServiceImpl;

public class App {

	private static final String OPERATION = "ADD";
	private static final String ADD = "ADD";
	private static final String VIEW = "VIEW";
	private static final String UPDATE = "UPDATE";
	private static final String DELETE = "DELETE";
	private static Product products = null;

	public static void main(String[] args) {

		ProductService productService = null;
		productService = ProductServiceImpl.getInstance();
		/*try {
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		products = new Product("JERE", "BIOGRAPHY", "1000", "2");
		if (products != null) {
			System.out.println("Products added successfully : ");
		}*/

		switch (OPERATION) {
			case ADD: {
				Product newUser = new Product("JERE", "BIOGRAPHY", "1000", "2");
				productService.addProduct(newUser);

			}
			case UPDATE: {
				Product newUser = new Product("JERE", "BIOGRAPHY", "1000", "2");
				productService.updateUser(UPDATE, newUser);
			}
			case VIEW: {
				productService.getProduct(VIEW);
			}
			case DELETE: {
				productService.delete(DELETE);
			}
			default: {
				System.out.println(" Enter a valid value");
			}
		}
	}
}
