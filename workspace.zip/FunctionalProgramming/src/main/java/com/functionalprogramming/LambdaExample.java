package com.functionalprogramming;

import java.util.Arrays;
import java.util.List;

public class LambdaExample {

	public static void main(String[] args) {

		List<String> cargo = Arrays.asList("Electronics", "Furniture", "Clothing");

		cargo.forEach(e -> System.out.println(e));
	}
}
