package com.hlag.inventorymanagementsystem.entity.repo;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.exception.InvalidNameException;

public interface ProductRepository {

	public Optional<Product> addProduct(String id) throws InvalidNameException;

	public Optional<Product> getById(String id);

	public Optional<List<Product>> getProduct(String id);

	public void delete(String id);

	public Product updateUser(String id, Product product);
}
