package com.hlag.inventorymanagementsystem.entity.service;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;

public interface ProductService {

	public Optional<Product> addProduct(Product product);

	public Optional<Product> getById(String id);

	public Optional<List<Product>> getProduct(String id);

	public void delete(String id);

	public Product updateUser(String id, Product product);
}
