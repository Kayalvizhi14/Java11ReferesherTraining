package com.productmanagement.service;

import java.util.List;
import java.util.Optional;

import com.productmanagement.Product;

public interface ProductService {

	public Product add(Product product);

	public Optional<Product> getProductById(String id);

	public Optional<List<Product>> getAllProducts();

	public Product update(String id, Product product);

	public void delete(String id);
}
