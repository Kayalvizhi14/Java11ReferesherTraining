package com.shippingmanagement.repo;

import java.util.Optional;

import com.shippingmanagement.entity.User;

public interface UserRepository {

	public User add(User user);

	public Optional<User> getUserById(String id);

	public User update(String id, User user);

	public void delete(String id);
}
