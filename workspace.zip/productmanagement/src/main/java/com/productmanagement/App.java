package com.productmanagement;

import com.productmanagement.service.ProductService;
import com.productmanagement.service.ProductServiceImpl;

public class App {

	static final ProductService service = ProductServiceImpl.getInstance();

	private static final String ADD = "ADD";
	private static final String VIEW = "VIEW";
	private static final String UPDATE = "UPDATE";
	private static final String DELETE = "DELETE";

	public static void main(String[] args) {

		String operation = "ADD";

		switch (operation) {

			case ADD:
				Product product = new Product("kay", "id", "100", "2");
				service.add(product);

			case VIEW:
				service.getAllProducts();

			case UPDATE:
				Product product1 = new Product("kay", "id", "100", "2");
				service.update("1", product1);

			case DELETE:
				String id = "1";
				service.delete(id);
		}

	}
}
