package com.hlag.logisticsystem.dto;

public class CargoItem {

	private double weight;
	private String type;
	private double dimension;

	public CargoItem(double weight, String type, double dimension) {

		this.weight = weight;
		this.type = type;
		this.dimension = dimension;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getDimension() {
		return dimension;
	}

	public void setDimension(double dimension) {
		this.dimension = dimension;
	}

	public double costByWeight(double weight) {

		double baseRate = 10.0;
		double costPerKg = 2.0;
		return baseRate + (costPerKg * weight);
	}
}
