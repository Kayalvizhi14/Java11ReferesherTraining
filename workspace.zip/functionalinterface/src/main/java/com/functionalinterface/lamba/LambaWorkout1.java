package com.functionalinterface.lamba;

public class LambaWorkout1 {

	public static void main(String[] args) {

		interface1 i = a -> a % 7 == 0;
		i.divide(14);
		System.out.println(i.divide(13));
	}

}

@FunctionalInterface
interface interface1 {

	public boolean divide(int a);
}