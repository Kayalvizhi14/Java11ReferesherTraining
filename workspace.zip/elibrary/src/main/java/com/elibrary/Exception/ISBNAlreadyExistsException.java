package com.elibrary.Exception;

public class ISBNAlreadyExistsException extends Exception {

	@Override
	public String toString() {
		return this.getMessage();
	}

	public ISBNAlreadyExistsException(String msg) {
		super(msg);
	}
}
