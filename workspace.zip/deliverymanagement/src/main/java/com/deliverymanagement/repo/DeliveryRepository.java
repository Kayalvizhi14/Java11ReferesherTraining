package com.deliverymanagement.repo;

import java.util.List;
import java.util.Optional;

import com.deliverymanagement.delivery.Delivery;
import com.deliverymanagement.exception.DataNotFoundException;

public interface DeliveryRepository {

	// Save a new delivery
	void save(Delivery delivery);

	// Find a delivery by its ID
	Optional<Delivery> findById(String deliveryId);

	// Get all deliveries
	List<Delivery> findAll();

	// Update an existing delivery
	void update(Delivery delivery);

	// Delete a delivery by its ID
	void deleteById(String deliveryId);

	// Get deliveries that are completed
	List<Delivery> findCompletedDeliveries();

	// -----------------


	public List<Delivery> getRevenue(String revenue);

	public List<Delivery> updateModifier(String id);

	public void deleteCompleted(String id);

	public double calculateTotalRevenue();

	public double averageDeliveryTime() throws DataNotFoundException;
}
