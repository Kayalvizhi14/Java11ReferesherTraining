package com.testing.test;

public abstract class AbstractTest implements I1, I2, I3 {

	@Override
	public void main5() {
		System.out.println("method 5 generated");

	}

	@Override
	public void main6() {
		System.out.println("method 6 generated");

	}

	@Override
	public void main7() {
		System.out.println("method 7 generated");

	}

	@Override
	public void method2() {
		System.out.println("method 2 generated");

	}

	@Override
	public void method3() {
		System.out.println("method 3 generated");

	}

	@Override
	public void method4() {
		System.out.println("method 4 generated");

	}

}
