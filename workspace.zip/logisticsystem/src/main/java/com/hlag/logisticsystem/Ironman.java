package com.hlag.logisticsystem;

public class Ironman implements Flyable {

	@Override
	public void fly() {
		System.out.println("fly from ironman");
	}

	public void display() {
		System.out.println("didplay");
	}

	public void demo(Flyable fly) {
		System.out.println("demoo");
	}

}
