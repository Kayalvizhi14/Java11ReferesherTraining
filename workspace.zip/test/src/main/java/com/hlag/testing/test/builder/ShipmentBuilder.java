package com.hlag.testing.test.builder;


public class ShipmentBuilder {

	private String destination;
	private String shipmentType;
	private String shippingDate;
	private String trackingNumber;
	private boolean insurance;
	private boolean giftWrap;
}
