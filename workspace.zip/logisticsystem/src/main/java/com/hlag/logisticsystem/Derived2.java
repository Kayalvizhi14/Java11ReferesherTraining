package com.hlag.logisticsystem;


public class Derived2 {

	public Derived2() {
		super();
	}

}
