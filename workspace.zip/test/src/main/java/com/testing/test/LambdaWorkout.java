package com.testing.test;

import java.util.function.Function;

import com.testing.test.LambdaExpression2.IOps;

public class LambdaWorkout {

	public static void main(String[] args) {
		IOps divideBy7 = (int a, int b) -> (a + b) / 7;

		int res = divideBy7.add(21, 14);
		System.out.println("Result of dividing by 7: " + res);

		demo((a, b) -> (a + b) / 7);
	}

	public static void demo(Interface1 interface1) {
		// System.out.println(interface1.divide(49, 14));

		/*Function<String, Integer> function = x -> x.length();
		System.out.println(function.apply("kay"));*/

		Function<String, Integer> function = x -> x.length();

		Function<Integer, Boolean> function1 = x -> x % 7 == 0;

		System.err.println(function1.apply(50));

		Function<Integer, Integer> function2 = x -> x * 2;

		int result = function.andThen(function2).apply("Kay");
		System.out.println(result);

	}

	@FunctionalInterface
	interface Interface1 {

		public int divide(int a, int b);
	}
}
