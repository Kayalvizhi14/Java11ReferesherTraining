package com.shippingmanagement.repo;

import java.util.Optional;

import com.shippingmanagement.entity.Order;

public interface OrderRepository {

	public Order add(Order order);

	public Optional<Order> getUserById(String id);

	public Order update(String id, Order order);

	public void delete(String id);
}
