package com.functionalprogramming;

public class FunctionalInterfaceExample {

	public static void main(String[] args) {

		cargoProcessor processor = cargo -> System.out.println("Processing cargo.." + cargo);

	}
}

@FunctionalInterface
interface cargoProcessor {

	void process(String cargo);
}