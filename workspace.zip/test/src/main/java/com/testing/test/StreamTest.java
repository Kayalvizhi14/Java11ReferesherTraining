package com.testing.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamTest {

	public static void main(String[] args) {

		long startTime = System.currentTimeMillis();
		List<String> words = Arrays.asList("apple", "banana", "cherry", "date");


		List<String> result = words.stream()
					.filter(e -> e.length() > 5)
					.map(e -> e.toUpperCase())
				.collect(Collectors.toList());

		result.stream().forEach(e -> System.out.println(e));
		result.forEach(e -> System.out.println(e));
		/*List<String> results = new ArrayList<>();
		for (String word : words) {
			if (word.length() > 5) {
				results.add(word);
			}
		}
		System.err.println(results);*/
		System.currentTimeMillis();
		long currentTimeMillis = System.currentTimeMillis();
		System.out.println("Current time in milliseconds: " + (startTime - currentTimeMillis));

	}

}