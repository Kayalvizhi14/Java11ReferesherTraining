package com.hlag.logisticsystem;

public class Base {

	int value;
	int value2;

	protected Base(int value, int value2) {
		this.value = value;
		this.value2 = value2;
	}

	public void test() {
		System.out.println("Base class");
	}


}
