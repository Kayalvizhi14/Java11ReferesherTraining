package com.testing.test.service;

import java.util.List;
import java.util.Optional;

import com.hlag.testing.test.entity.User;

public interface UserService {

	public User addUser(User user);

	public Optional<User> getUserById(String id);

	public Optional<List<User>> getUsers();

	public void deleteUser(String id);

	public User UpdateUser(String id, String user);
}
