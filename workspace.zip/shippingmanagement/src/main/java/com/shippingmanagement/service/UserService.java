package com.shippingmanagement.service;

import java.util.List;
import java.util.Optional;

import com.shippingmanagement.entity.User;

public interface UserService {

	public User add(User user);

	public Optional<User> getUserById(String id);

	public List<User> getAllUsers();

	public User update(String id, User user);

	public void delete(String id);
}
