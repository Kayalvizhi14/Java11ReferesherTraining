package com.deliverymanagement.exception;


public class DataNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return this.getMessage();
	}

	public DataNotFoundException(String msg) {
		super(msg);
	}
}
