package com.employeemanagement.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.employeemanagement.employee.Employee;

public class EmployeeRepository {

	List<Employee> employees = new ArrayList<>();

	public List<Employee> filterEmployee() {
		return employees.stream().filter(e -> e.getSalary() > 50000).collect(Collectors.toList());

	}

	Map<String, Double> filter = employees.stream()
			.filter(e -> e.getSalary() > 500000)
			.collect(Collectors.toMap(e -> e.getName(), e -> e.getSalary()));

	double toSalary = employees.stream().filter(e -> e.getSalary() > 500000)
			.map(e -> e.getSalary())
			.reduce(0.0, Double::sum);
}
