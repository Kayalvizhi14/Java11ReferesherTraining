package com.shippingmanagement.entity;

import java.util.UUID;

public class Order {

	private UUID id;
	private UUID customer;
	private UUID destination;
	private UUID weight;
	private UUID status;

	public Order(UUID id, UUID customer, UUID destination, UUID weight, UUID status) {
		super();
		this.id = id;
		this.customer = customer;
		this.destination = destination;
		this.weight = weight;
		this.status = status;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public UUID getCustomer() {
		return customer;
	}

	public void setCustomer(UUID customer) {
		this.customer = customer;
	}

	public UUID getDestination() {
		return destination;
	}

	public void setDestination(UUID destination) {
		this.destination = destination;
	}

	public UUID getWeight() {
		return weight;
	}

	public void setWeight(UUID weight) {
		this.weight = weight;
	}

	public UUID getStatus() {
		return status;
	}

	public void setStatus(UUID status) {
		this.status = status;
	}

}
