package com.functionalinterface.lamba;

public class LambdaWorkout2 {

	public static void main(String[] args) {

		// --------------Even or Odd
		interface2 i2 = a -> a % 2 == 0;
		int num = 9;
		if (i2.check(num)) {
			System.out.println("Even");
		}
		System.out.println("odd");

		// -----------------Add

		interface3 i3 = (a, b) -> a + b;
		System.out.println(i3.add(12, 20));
	}
}

@FunctionalInterface
interface interface2 {

	public boolean check(int a);

}

@FunctionalInterface
interface interface3 {

	public int add(int a, int b);
}