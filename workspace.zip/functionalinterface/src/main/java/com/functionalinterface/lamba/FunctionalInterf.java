package com.functionalinterface.lamba;

public class FunctionalInterf {

	public static void main(String[] args) {

		// ---------------By using impl class
		Impl i = new Impl();
		i.test();
		i.test2();

		// ----------by using anonymous inner type
		inter i2 = new inter() {

			@Override
			public void test() {
				System.out.println("Function test");

			}

			@Override
			public void test2() {
				System.out.println("Function test2");
			}
		};
		i2.test();
		i2.test2();

		// ------- lambda expression

		inter i3 = () -> System.out.println("Helloo from lanbda expression");
		i3.test();

	}
}

@FunctionalInterface
interface inter {

	public void test();

	public default void test2() {
		System.out.println("Hello from default");
	}
}

class Impl implements inter {

	@Override
	public void test() {
		System.out.println("Hello from test");

	}

	@Override
	public void test2() {
		System.out.println("Hello from impl test2");
	}
}