package com.hlag.logisticsystem.dto;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

public class Package {

	private final String trackingId;
	private double weight;
	private String destination;
	private String status;
	private List<String> milestones;

	/*public Package() {
		this.trackingId = "";
	}
	
	public Package(String trackingId, double weight, String destination, String status, List<String> milestones) {
	
		this.trackingId = trackingId;
		this.destination = destination;
		this.status = status;
		this.milestones = milestones;
		setWeight(weight);
	}*/

	public String getTrackingId() {
		return trackingId;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		if (weight <= 0) {
			throw new IllegalArgumentException("weight shouldn't be negative");
		}
		this.weight = weight;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getStatus() {
		return status;
	}

	public List<String> getMilestones() {
		return Collections.unmodifiableList(milestones);// we cant't change tracking details its only depends on shipper
																										// side
	}

	public void markAsDelivered(String status) {

		// in transit
		if (this.status.equals(status)) {
			throw new IllegalArgumentException("package is in transit");
		}
		this.status = "delivered";
		this.milestones.add("delivered on" + LocalDateTime.now());
	}

	private Package() {
		this.trackingId = "";
	}

	private static Package pack;

	public static Package getInstance() {

		if (pack == null) {
			pack = new Package();
		}
		return pack;
	}
}
