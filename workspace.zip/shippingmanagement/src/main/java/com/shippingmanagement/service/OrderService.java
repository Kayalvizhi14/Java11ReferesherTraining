package com.shippingmanagement.service;

import java.util.Optional;

import com.shippingmanagement.entity.Order;

public interface OrderService {

	public Order add(Order user);

	public Optional<Order> getUserById(String id);

	public Order getAllOrders();

	public Order update(String id, Order user);

	public void delete(String id);

}
