package com.shippingmanagement.repo;

import java.util.Optional;

import com.shippingmanagement.entity.Order;


public class OrderRepositoryImpl implements OrderRepository {

	@Override
	public Order add(Order order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Order> getUserById(String id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Order update(String id, Order order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub

	}

}
