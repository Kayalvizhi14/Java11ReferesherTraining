package com.shippingmanagement.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.shippingmanagement.entity.User;

public class UserRepositoryImpl implements UserRepository {

	List<User> users = new ArrayList<>();
	@Override
	public User add(User user) {
		users.add(user);
		return user;
	}

	@Override
	public Optional<User> getUserById(String id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public User update(String id, User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub

	}

}
