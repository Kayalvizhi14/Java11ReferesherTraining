package com.hlag.logisticsystem;

public class Test {

	public static void testify(Flyable flying) {

		flying.fly();
	}

	public static void main(String[] args) {

		Flyable f = new Ironman();
		f.fly();

		testify(f);

		testify(new Ironman());
	}
}
