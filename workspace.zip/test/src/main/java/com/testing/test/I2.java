package com.testing.test;


public interface I2 {

	public void main5();

	public void main6();

	public void main7();
}
