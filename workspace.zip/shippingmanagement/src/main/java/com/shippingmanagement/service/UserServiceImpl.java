package com.shippingmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.shippingmanagement.entity.User;

public class UserServiceImpl implements UserService {

	List<User> users = new ArrayList<>();

	@Override
	public User add(User user) {
		if (user != null) {
			users.add(user);
		}
		return user;
	}

	@Override
	public Optional<User> getUserById(String id) {
		return users.stream().filter(u -> u.getId().equals(id)).findFirst();
	}

	@Override
	public List<User> getAllUsers() {
		return new ArrayList<>(users);
	}

	@Override
	public User update(String id, User user) {

		Optional<User> existingUser = getUserById(id);

		existingUser.ifPresent(e -> {

			users.remove(existingUser.get());
			users.add(user);
		});
		return user;
	}
	/*	Optional<User> us = getUserById(id);
		if (us.isPresent()) {
			users.remove(us.get());
			users.add(user);
		}
		return user;*/

	@Override
	public void delete(String id) {
		getUserById(id).map(u -> users.remove(u));

	}

}
