package com.hlag.logisticsystem.service;


public class Inventory {

}
