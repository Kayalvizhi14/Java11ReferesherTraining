package com.hlag.logisticsystem;

public class App {

	int value;
	int value2;

	public App(int value, int value2) {
	
			this.value = value;
			this.value2 = value2;
		}



}
