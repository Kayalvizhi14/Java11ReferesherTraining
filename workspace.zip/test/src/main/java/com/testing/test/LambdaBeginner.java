package com.testing.test;

public class LambdaBeginner {

	public static void main(String[] args) {

		/*Greeter g = (String name) -> name;
		String result = g.greet("Reuuter");
		System.out.println("Hello greet .. " + result);
		// greets(result);
		*/

		Greeter greet = name -> name;
		System.out.println("Hello.. greet" + greet);

	}

}

@FunctionalInterface
interface Greeter {

	public String greet(String name);
}
