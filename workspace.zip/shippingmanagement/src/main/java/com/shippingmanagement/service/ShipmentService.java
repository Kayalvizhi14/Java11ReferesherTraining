package com.shippingmanagement.service;

import java.util.Optional;

import com.shippingmanagement.entity.Shipment;

public interface ShipmentService {

	public Shipment add(Shipment user);

	public Optional<Shipment> getUserById(String id);

	public Shipment getAllShipments();

	public Shipment update(String id, Shipment user);

	public void delete(String id);
}
