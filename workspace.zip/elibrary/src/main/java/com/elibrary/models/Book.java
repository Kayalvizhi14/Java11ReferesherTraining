package com.elibrary.models;

import java.time.LocalDate;

public class Book {

	private String isbn;
	private String name;
	private String author;
	private String publisher;
	private LocalDate issuedDate;
	private LocalDate dueDate;

	public Book(String isbn, String name, String author, String publisher, LocalDate issuedDate, LocalDate dueDate) {

		this.isbn = isbn;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.issuedDate = issuedDate;
		this.dueDate = dueDate;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public LocalDate getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(LocalDate issuedDate) {
		this.issuedDate = issuedDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", name=" + name + ", author=" + author + ", publisher=" + publisher + ", issuedDate="
				+ issuedDate + ", dueDate=" + dueDate + "]";
	}

}
