package com.testing.test;

public interface I3 {

	public void main8();

	public void main9();
}
