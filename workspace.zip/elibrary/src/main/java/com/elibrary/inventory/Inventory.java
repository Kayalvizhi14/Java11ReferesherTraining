package com.elibrary.inventory;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.elibrary.Exception.ISBNAlreadyExistsException;
import com.elibrary.models.Book;
import com.elibrary.models.User;

public class Inventory {

	public List<Book> books = new ArrayList<>();
	public Map<String, User> users;

	public void addUser(Book book) throws ISBNAlreadyExistsException {
		for (Book b : books) {
			if (b.getIsbn().equals(book.getIsbn())) {
				throw new ISBNAlreadyExistsException("ISBN Already exists");
			}
		}
		books.add(book);
	}

	public Optional<Book> getBookByName(String name) {

		for (Book b : books) {
			if (b.getName().equalsIgnoreCase(name)) {
				Optional.of(b);
			}
		}
		return Optional.empty();
	}

	public List<Book> listAllBooks() {
		return new ArrayList<>(books);
	}

	public List<Book> getBookByIssueDte(LocalDate issueDate) {
		List<Book> result = new ArrayList<>();
		for (Book book : books) {
			if (issueDate.equals(book.getIssuedDate())) {
				result.add(book);
			}
		}
		return result;
	}

	public List<Book> searchByAuthor(String author) {
		List<Book> result = new ArrayList<>();
		for (Book book : books) {
			if (book.getAuthor().equalsIgnoreCase(author)) {
				result.add(book);
			}
		}
		return result;
	}

	public List<Book> searchBookByPublisher(String publisher) {
		List<Book> result = new ArrayList<>();
		for (Book b : books) {
			if (b.getPublisher().equalsIgnoreCase(publisher)) {
				result.add(b);
			}
		}
		return result;
	}

	public Book updateBook(Book book) {

		for (int i = 0; i < books.size(); i++) {
			Book b = books.get(i);
			if (b.getIsbn().equals(book.getIsbn())) {
				books.set(i, book);
				return book;
			}

		}
		return null;
	}

	public User getUserById(String userId) {
		return users.get(userId);
	}

	public Map<String, User> getUsers() {
		return users;
	}

	public boolean isBookAvailable(String isbn) {
		for (Book book : books) {
			if (book.getIsbn().equals(isbn) && book.isAvailable) {
				return true;
			}
		}
		return false;
	}

	public List<Book> getBorrowedBooks() {
		List<Book> borrowedBooks = new ArrayList<>();
		for (Book b : books) {
			if (!b.isAvalaible) {
				borrowedBooks.add(b);
			}
			return borrowedBooks;
		}
	}

	public boolean renewBooks(String isbn, User user, LocalDate renewDate) {
		for (Book book : books) {
			if (book.getIsbn().equals(isbn) && !isAvailable && users.containsKey(user.getUserId())) {
				book.setDueDate(renewDate);
				return true;
			}
			return false;
		}
	}
}