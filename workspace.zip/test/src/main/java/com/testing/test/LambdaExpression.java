package com.testing.test;

public class LambdaExpression {

	public static void main(String[] args) {

		/*I5 i5 = new I1IMPL();
		boolean result = i5.test();
		i5.test2();*/

		I5 i6 = () -> {
			System.out.println("hello from lambda");

		};
		// System.out.println(i6.test());
		i6.test2();
		i6.test();
		I5 i5 = new I5() {

			@Override
			public void test() {
				// TODO Auto-generated method stub
				// return true;
			}
			
			/*@Override
			public void test2() {
				System.out.println("hello from overriden");
			}*/
		};
		i5.test();
	}

}


	@FunctionalInterface
	interface I5 {

		public void test();

		public default void test2() {
			System.out.println("hello from default");
		}
	}


class I1IMPL implements I5 {

			@Override
			public void test() {
				// TODO Auto-generated method stub
				System.out.println("Hello from test");
				// return true;

			}

			@Override
			public void test2() {
				System.out.println("hello from test2");
			}
	}

