package com.hlag.testing.test.entity;

import java.util.UUID;
import java.util.regex.Pattern;

import com.testing.test.Exception.InvalidNameException;

public class User {

	private static final Pattern EMAIL_PATTERN = Pattern.compile("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$");

	private static final Pattern MOBILE_PATTERN = Pattern.compile("^\\d{10}$");

	private static final int MIN_PASSWORD_LENGTH = 8;
	private static final int MAX_NAME_LENGTH = 10;

	private UUID userId;
	private String name;
	private String mobileNo;
	private String email;
	private String password;

	public User(String name, String mobileNo, String email, String password) throws InvalidNameException {

		userId = UUID.randomUUID();
		setName(name);
		setMobileNo(mobileNo);
		setEmail(email);
		setPassword(password);
	}

	public UUID getUserId() {
		return userId;
	}

	public void setId() {
		this.userId = UUID.randomUUID();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) throws InvalidNameException {
		if (name == null || name.length() > MAX_NAME_LENGTH) {
			throw new InvalidNameException("Name shouldn't be Null");
		}
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) throws InvalidNameException {
		String mobileNoAsString = String.valueOf(mobileNo);
		if (!MOBILE_PATTERN.matcher(mobileNoAsString).matches()) {
			throw new InvalidNameException("MobNo shouldn't be Null");
		}
		this.mobileNo = mobileNo;

	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) throws InvalidNameException {
		if (email == null || !EMAIL_PATTERN.matcher(email).matches()) {
			throw new InvalidNameException("email shouldn't be Null");
		}
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) throws InvalidNameException {
		if (password.length() > 8) {
			throw new InvalidNameException("Password must be at least " + MIN_PASSWORD_LENGTH + " characters long.");
		}
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", mobileNo=" + mobileNo + ", email=" + email + ", password="
				+ password + "]";
	}

}
