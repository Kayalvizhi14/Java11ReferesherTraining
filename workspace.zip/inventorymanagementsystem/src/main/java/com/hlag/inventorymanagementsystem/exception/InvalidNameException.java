package com.hlag.inventorymanagementsystem.exception;

public class InvalidNameException extends Exception {

	@Override
	public String toString() {
		return this.getMessage();
	}

	public InvalidNameException(String msg) {
		super(msg);
	}
}
